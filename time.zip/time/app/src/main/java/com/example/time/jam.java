package com.example.time;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import android.os.Bundle;

public class jam extends AppCompatActivity {

    private TimePicker timePicker;
    private TextView Output;
    private Button SetChange;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jam);
        timePicker = findViewById(R.id.get_time);
        Output = findViewById(R.id.output);
        SetChange = findViewById(R.id.set_waktu);
        SetChange = findViewById(R.id.set_waktu);
        SetChange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Output.setText(setTime());
                Toast.makeText(getApplicationContext(), "Berhasil Diubah", Toast.LENGTH_SHORT).show();
            }
        });
    }
    public String setTime() {
        String waktu = "Waktu : " + timePicker.getCurrentHour() + ":" + timePicker.getCurrentMinute();
        return waktu;
    }
}